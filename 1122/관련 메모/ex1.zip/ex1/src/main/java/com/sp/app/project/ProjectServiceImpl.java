package com.sp.app.project;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.app.code.Option;
import com.sp.app.common.CommonDAO;

@Service("project.projectService")
public class ProjectServiceImpl implements ProjectService {
	@Autowired
	CommonDAO dao;

	@Override
	public void insertProject(Project dto) throws Exception {
		try {
			Long seq = dao.selectOne("project.project_seq");
			dto.setPjtId(seq);

			dao.insertData("project.insertProject", dto);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<Project> listProject(Map<String, Object> map) {
		List<Project> list = null;
		
		try {
			list = dao.selectList("project.listProject", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public List<Project> searchProject(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Option> listOption(Map<String, Object> map) {
		List<Option> optionList = null;
		
		try {
			optionList = dao.selectList("option.listOption", map);
		} catch (Exception e) {
			e.printStackTrace();
 		}
		
		return optionList;
	}

	@Override
	public int dataCount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Project readProject(long pjtId) {
		Project dto = null;
		
		try {
			dto = dao.selectOne("project.readProject", pjtId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}

	@Override
	public void updateProject(Project dto) throws Exception {
		try {
		dao.updateData("project.updateProject", dto);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public void deleteProject(Project dto) throws Exception {
		try {
			dao.updateData("project.deleteProject", dto);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	/*
	@Override
	public void deleteProject(long pjtId) throws Exception {
		try {
			dao.deleteData("project.deleteProject", pjtId);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	*/

}
