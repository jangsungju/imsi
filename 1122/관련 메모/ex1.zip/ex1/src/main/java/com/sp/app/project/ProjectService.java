package com.sp.app.project;

import java.util.List;
import java.util.Map;

import com.sp.app.code.Option;

public interface ProjectService {
	public void insertProject(Project dto) throws Exception;
	public List<Project> listProject(Map<String, Object> map);
	public List<Project> searchProject(Map<String, Object> map);
	public List<Option> listOption(Map<String, Object> map);
	public int dataCount(Map<String, Object> map);
	public Project readProject(long pjtId);
	public void updateProject(Project dto) throws Exception;
	// public void deleteProject(long pjtId) throws Exception;
	public void deleteProject(Project dto) throws Exception;
}
