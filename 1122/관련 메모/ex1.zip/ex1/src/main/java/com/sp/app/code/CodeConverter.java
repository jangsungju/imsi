package com.sp.app.code;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class CodeConverter {
	
	public String depToNumber(String value) {
	    if ("풀스택".equals(value)) {
	        return "1";
	    } else if ("백엔드".equals(value)) {
	        return "2";
	    } else if ("프론트엔드".equals(value)) {
	        return "3";
	    }
	    return ""; 
	}
	
	public String gradeToNumber(String value) {
	    if ("특급".equals(value)) {
	        return "1";
	    } else if ("고급".equals(value)) {
	        return "2";
	    } else if ("중급".equals(value)) {
	    	return "3";
	    } else if ("초급".equals(value)) {
		return "4";
	    }
	    return ""; 
	}
	
	public String rankToNumber(String value) {
	    if ("사장".equals(value)) {
	        return "1";
	    } else if ("상무".equals(value)) {
	        return "2";
	    } else if ("이사".equals(value)) {
	        return "3";
	    } else if ("부장".equals(value)) {
	    	return "4";
	    } else if ("차장".equals(value)) {
        	return "5";
        } else if ("과장".equals(value)) {
        	return "6";
        } else if ("대리".equals(value)) {
        	return "7";
        } else if ("사원".equals(value)) {
        	return "8";
        }
	    return ""; 
	}
	public String staToNumber(String value) {
	    if ("재직".equals(value)) {
	        return "1";
	    } else if ("휴직".equals(value)) {
	        return "2";
	    } else if ("퇴직".equals(value)) {
	        return "3";
	    }
	    return ""; 
	}
	
	public String coToNumber(String value) {
	    if ("삼성".equals(value)) {
	        return "1";
	    } else if ("현대자동차".equals(value)) {
	        return "2";
	    } else if ("SK".equals(value)) {
	        return "3";
	    } else if ("LG".equals(value)) {
	        return "4";
	    } else if ("롯데".equals(value)) {
	        return "5";
	    } else if ("한화".equals(value)) {
	        return "6";
	    } else if ("농협".equals(value)) {
	        return "7";
	    } else if ("GS".equals(value)) {
	        return "8";
	    } else if ("신세계".equals(value)) {
	        return "9";
	    } else if ("두산".equals(value)) {
	        return "10";
	    } else if ("동부".equals(value)) {
	        return "11";
	    } else if ("CJ".equals(value)) {
	        return "12";
	    } 
	    return "";
	}
	
	
	public String roleToNumber(String value) {
	    if ("Project Manager".equals(value)) {
	        return "1";
	    } else if ("Project Leader".equals(value)) {
	        return "2";
	    } else if ("Application Architect".equals(value)) {
	        return "3";
	    } else if ("Technical Architect".equals(value)) {
	        return "4";
	    } else if ("Data Architect".equals(value)) {
	        return "5";
	    } else if ("Quality Architect".equals(value)) {
	        return "6";
	    } else if ("Business Architect".equals(value)) {
	        return "7";
	    } else if ("Developer".equals(value)) {
	        return "8";
	    } 
	    return "";
	}
	
	public String getRankName(String rankNumber) {
	    Map<String, String> rankMapping = new HashMap<>();
	    rankMapping.put("1", "사장");
	    rankMapping.put("2", "상무");
	    rankMapping.put("3", "이사");
	    rankMapping.put("4", "부장");
	    rankMapping.put("5", "차장");
	    rankMapping.put("6", "과장");
	    rankMapping.put("7", "대리");
	    rankMapping.put("8", "사원");
	    return rankMapping.get(rankNumber);
	}
    
	public  String getGradeName(String gradeNumber) {
		Map<String, String> gradeMapping = new HashMap<>();
		gradeMapping.put("1", "특급");
		gradeMapping.put("2", "고급");
		gradeMapping.put("3", "중급");
		gradeMapping.put("4", "초급");
		return gradeMapping.get(gradeNumber);
	}
 
	public  String getStaName(String staNumber) {
		Map<String, String> staMapping = new HashMap<>();
		staMapping.put("1", "재직");
		staMapping.put("2", "휴직");
		staMapping.put("3", "퇴직");
		return staMapping.get(staNumber);
	}
    
	public  String getDepName(String depNumber) {
	    Map<String, String> depMapping = new HashMap<>();
	    depMapping.put("1", "풀스택");
	    depMapping.put("2", "백엔드");
	    depMapping.put("3", "프론트엔드");
	    return depMapping.get(depNumber);
	}
	
	public String getCoName(String coNumber) {
	    Map<String, String> coMapping = new HashMap<>();
	    coMapping.put("1", "삼성");
	    coMapping.put("2", "현대자동차");
	    coMapping.put("3", "SK");
	    coMapping.put("4", "LG");
	    coMapping.put("5", "롯데");
	    coMapping.put("6", "한화");
	    coMapping.put("7", "농협");
	    coMapping.put("8", "GS");
	    coMapping.put("9", "신세계");
	    coMapping.put("10", "두산");
	    coMapping.put("11", "동부");
	    coMapping.put("12", "CJ");
	    return coMapping.get(coNumber);
	}
	
	public String getRoleName(String roleNumber) {
	    Map<String, String> roleMapping = new HashMap<>();
	    roleMapping.put("1", "Project Manager");
	    roleMapping.put("2", "Project Leader");
	    roleMapping.put("3", "Application Architect");
	    roleMapping.put("4", "Technical Architect");
	    roleMapping.put("5", "Data Architect");
	    roleMapping.put("6", "Quality Architect");
	    roleMapping.put("7", "Business Architect");
	    roleMapping.put("8", "Developer");
	    return roleMapping.get(roleNumber);
	}
}
