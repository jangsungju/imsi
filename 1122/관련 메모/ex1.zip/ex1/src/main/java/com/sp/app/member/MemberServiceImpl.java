package com.sp.app.member;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.app.code.Option;
import com.sp.app.common.CommonDAO;
import com.sp.app.common.FileManager;

@Service("member.memberService")
public class MemberServiceImpl implements MemberService{
	@Autowired 
	CommonDAO dao;
	
	@Autowired 
	FileManager fileManager;
	
	
	@Override
	public void insertMember(Member dto, String pathname) throws Exception {
		try {
			
			String saveFilename = fileManager.doFileUpload(dto.getSelectFile(), pathname);
			if(saveFilename != null) {
				dto.setProfileImg(saveFilename);
			}
			
			dao.insertData("member.insertMember", dto);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}

	@Override
	public List<Member> listMember(Map<String, Object> map) {
		List<Member> list = null;
		
		try {
			list = dao.selectList("member.listMember", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public int dataCount(Map<String, Object> map) {
		int result = 0;
		
		try {
			result = dao.selectOne("member.dataCount", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Member readMember(long userId) {
		Member dto = null;
		
		try {
			dto = dao.selectOne("member.readMember", userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	
	@Override
	public Member readFile(long userId) {
		Member dto2 = null;
		try {
			dto2 = dao.selectOne("member.readFile", userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;
	}

	@Override
	public List<Option> listOption(Map<String, Object> map) {
		List<Option> optionList = null;
		
		try {
			optionList = dao.selectList("option.listOption", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return optionList;
	}

	@Override
	public void updateMember(Member dto, String pathname) throws Exception {
		try {
			String saveFilename = fileManager.doFileUpload(dto.getSelectFile(), pathname);
			
			if (saveFilename != null) {
				if(dto.getProfileImg() != null && dto.getProfileImg().length() != 0) {
					fileManager.doFileDelete(dto.getProfileImg(), pathname);
				}
				
				dto.setProfileImg(saveFilename);
			}
			dao.updateData("member.updateMember", dto);
			
		
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/*
	@Override
	public void deleteMember(long userId, String pathname) throws Exception {
		try {
			
			Member dto = readMember(userId);
			
			fileManager.doFileDelete(dto.getProfileImg(), pathname);
			dao.deleteData("member.deleteMember", userId);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	*/
	
	@Override
	public void deleteMember(Member dto) throws Exception {
		try {
			dao.updateData("member.deleteMember", dto);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}

	@Override
	public List<Member> searchMember(Map<String, Object> map) {
		List<Member> searchList = null;
		
		try {
			searchList = dao.selectList("member.searchMember", map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return searchList;
	}


	

}
