package com.sp.app.pjtmem;

import java.util.List;
import java.util.Map;

import com.sp.app.member.Member;
import com.sp.app.mempjt.Mempjt;

public interface PjtmemService {
	public List<Member> listMember(Map<String, Object> map);
	public List<Mempjt> listPjtmem(Map<String, Object> map);
	public Mempjt readPjtmem(Mempjt dto) throws Exception;
}
