package com.sp.app.mempjt;

public class Mempjt {
	public long userId;
	public long pjtId;
	public String pjtName;
	public String clientCo;
	public String pjtIndt;
	public String pjtWtdt;
	public String pjtRole;
	public String pjtStdt;
	public String pjtEnddt;
	public String name;
	public String grade;
	public String rank;
	
	
	public String getClientCo() {
		return clientCo;
	}
	public void setClientCo(String clientCo) {
		this.clientCo = clientCo;
	}
	public String getPjtName() {
		return pjtName;
	}
	public void setPjtName(String pjtName) {
		this.pjtName = pjtName;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getPjtId() {
		return pjtId;
	}
	public void setPjtId(long pjtId) {
		this.pjtId = pjtId;
	}
	public String getPjtIndt() {
		return pjtIndt;
	}
	public void setPjtIndt(String pjtIndt) {
		this.pjtIndt = pjtIndt;
	}
	public String getPjtWtdt() {
		return pjtWtdt;
	}
	public void setPjtWtdt(String pjtWtdt) {
		this.pjtWtdt = pjtWtdt;
	}
	public String getPjtRole() {
		return pjtRole;
	}
	public void setPjtRole(String pjtRole) {
		this.pjtRole = pjtRole;
	}
	public String getPjtStdt() {
		return pjtStdt;
	}
	public void setPjtStdt(String pjtStdt) {
		this.pjtStdt = pjtStdt;
	}
	public String getPjtEnddt() {
		return pjtEnddt;
	}
	public void setPjtEnddt(String pjtEnddt) {
		this.pjtEnddt = pjtEnddt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	
	
}
