package com.sp.app.member;

import java.util.List;
import java.util.Map;

import com.sp.app.code.Option;

public interface MemberService {
	public void insertMember(Member dto, String pathname) throws Exception;
	public List<Member> listMember(Map<String, Object> map);
	public List<Member> searchMember(Map<String, Object> map);
	public List<Option> listOption(Map<String, Object> map);
	public int dataCount(Map<String, Object> map);
	public Member readMember(long userId);
	public Member readFile(long userId);
	public void updateMember(Member dto, String pathname) throws Exception;
	// public void deleteMember(long userId, String pathname) throws Exception;
	public void deleteMember(Member dto) throws Exception;
}
