package com.sp.app.mempjt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.app.code.Option;
import com.sp.app.code.CodeConverter;
import com.sp.app.member.Member;
import com.sp.app.member.MemberService;
import com.sp.app.project.Project;
import com.sp.app.project.ProjectService;

@Controller
@RequestMapping("/mempjt/")
public class MempjtController {	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private MempjtService mempjtService;
	
	@Autowired
	private CodeConverter codeConverter;
	
	@RequestMapping("list")
	public String list(
			@RequestParam long userId,
			Model model) throws Exception{

		
		Member member = memberService.readMember(userId);
		
		if(member == null) {
			return "redirect:/member/list";
		}
		
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("userId", userId);

		List<Mempjt> list = mempjtService.listMempjt(map);
		
		for(Mempjt mempjt : list) {
			String coNumber = mempjt.getClientCo();
			String coKorean = codeConverter.getCoName(coNumber);
			mempjt.setClientCo(coKorean);

			String roleNumber = mempjt.getPjtRole();
			String roleKorean = codeConverter.getRoleName(roleNumber);
			mempjt.setPjtRole(roleKorean);
		}
		
		model.addAttribute("userId", userId);
		model.addAttribute("member", member);
		model.addAttribute("list", list);
		return "mempjt/mempjtList";
	}
	
	@RequestMapping("write")
	public String writeForm(
			@RequestParam(value = "pjtName", required = false) String pjtName,
			@RequestParam(value = "clientCo", required = false) String clientCo,
			@RequestParam Long userId,
			Model model) throws Exception{ 
		
		Map<String, Object> clientMap = new HashMap<String, Object>();
		clientMap.put("dcode", "D600");
		
		List<Option> clientOptionList = projectService.listOption(clientMap);
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("pjtName", pjtName);
		
		String coValue = codeConverter.coToNumber(clientCo);
		if (clientCo != null && !clientCo.isEmpty()) {
		    map.put("clientCo", coValue);
		}
		
	    
		List<Project> list = projectService.listProject(map);
		
		for(Project project : list) {
			String coNumber = project.getClientCo();
			String coKorean = codeConverter.getCoName(coNumber);
			project.setClientCo(coKorean);
		}
		
		model.addAttribute("userId", userId);
		model.addAttribute("clientOptionList", clientOptionList);
		model.addAttribute("list", list);
		model.addAttribute("mode", "write");
		
		return "mempjt/mempjtWrite";
		
	}
	
	@PostMapping("write")
	public String writeSubmit(
			@RequestParam("pjtId") List<Long> pjtIds,
			@RequestParam("userId") Long userId) throws Exception{
		
		try {
			for(Long pjtId : pjtIds) {
	            Mempjt dto = new Mempjt();
				dto.setUserId(userId);
				dto.setPjtId(pjtId);
				mempjtService.insertMempjt(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	    String redirectUrl = "redirect:/mempjt/list?userId=" + userId;

		
		return redirectUrl;
	}
	
	@GetMapping(value = "article")
	public String article(@RequestParam long pjtId,
			@RequestParam long userId,
			Model model) throws Exception{
		
		Mempjt dto2 = new Mempjt();
		dto2.setUserId(userId);
		dto2.setPjtId(pjtId);
		Mempjt dto = mempjtService.readMempjt(dto2);
		
		String coNumber = dto.getClientCo();
		String coKorean = codeConverter.getCoName(coNumber);
		dto.setClientCo(coKorean);

		String roleNumber = dto.getPjtRole();
		String roleKorean = codeConverter.getRoleName(roleNumber);
		dto.setPjtRole(roleKorean);
		
		model.addAttribute("dto", dto);
		
		return "mempjt/mempjtArticle";
	}
	
	@RequestMapping(value = "delete")
	public String deleteMempjt(@RequestParam("pjtId") List<Long> pjtIds,
			@RequestParam("userId") Long userId,
			Mempjt dto) throws Exception{
		
		for(Long pjtId : pjtIds) {
            dto = new Mempjt();
			dto.setUserId(userId);
			dto.setPjtId(pjtId);
	        mempjtService.deleteMempjt(dto);
		}
		
	    String redirectUrl = "redirect:/mempjt/list?userId=" + userId;
		
		return redirectUrl;
	}
	
	@GetMapping(value = "update")
	public String updateForm(@RequestParam long pjtId,
			@RequestParam long userId,
			Model model) throws Exception{
		
		Mempjt dto2 = new Mempjt();
		dto2.setUserId(userId);
		dto2.setPjtId(pjtId);
		Mempjt dto = mempjtService.readMempjt(dto2);
		
		Map<String, Object> roleMap = new HashMap<String, Object>();
		roleMap.put("dcode", "D700");
		
		List<Option> roleOptionList = projectService.listOption(roleMap);
	   
	    model.addAttribute("userId", userId);
	    model.addAttribute("pjtId", pjtId);
		model.addAttribute("roleOptionList", roleOptionList);
		model.addAttribute("roleMapping", codeConverter.getRoleName(dto.getPjtRole()));
	    model.addAttribute("coMapping", codeConverter.getCoName(dto.getClientCo()));
		model.addAttribute("dto", dto);
		
		return "mempjt/mempjtUpdate";
	}
	
	@PostMapping(value = "update")
	public String updateSubmit(Mempjt dto,
			@RequestParam long pjtId,
			@RequestParam long userId
			) throws Exception{
		
		try {
			String roleValue = codeConverter.roleToNumber(dto.getPjtRole());
			dto.setPjtRole(roleValue);
			Mempjt dto2 = new Mempjt();
			dto2.setUserId(userId);
			dto2.setPjtId(pjtId);
			mempjtService.updateMempjt(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	    String redirectUrl = "redirect:/mempjt/list?userId=" + userId;
		
		return redirectUrl;
	}
	

}
