package com.sp.app.home;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	
	@GetMapping("home")
	public String house(Model model, HttpSession session){
		
		return "home/home";
	}
	
}
