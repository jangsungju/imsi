package com.sp.app.mempjt;

import java.util.List;
import java.util.Map;

public interface MempjtService {
	public void insertMempjt(Mempjt dto) throws Exception;
	public List<Mempjt> listMempjt(Map<String, Object> map);
	public void deleteMempjt(Mempjt dto) throws Exception;
	public Mempjt readMempjt(Mempjt dto) throws Exception;
	public void updateMempjt(Mempjt dto) throws Exception;
}
