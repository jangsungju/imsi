package com.sp.app.code;

public class Option {
	private String dcode;
	private String dcodeName;
	private String dtlcd;
	private String dtlcdName;
	public String getDcode() {
		return dcode;
	}
	public void setDcode(String dcode) {
		this.dcode = dcode;
	}
	public String getDcodeName() {
		return dcodeName;
	}
	public void setDcodeName(String dcodeName) {
		this.dcodeName = dcodeName;
	}
	public String getDtlcd() {
		return dtlcd;
	}
	public void setDtlcd(String dtlcd) {
		this.dtlcd = dtlcd;
	}
	public String getDtlcdName() {
		return dtlcdName;
	}
	public void setDtlcdName(String dtlcdName) {
		this.dtlcdName = dtlcdName;
	}
	
	
}
