package com.sp.app.pjtmem;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.app.code.Option;
import com.sp.app.code.CodeConverter;
import com.sp.app.member.Member;
import com.sp.app.mempjt.Mempjt;
import com.sp.app.mempjt.MempjtService;
import com.sp.app.project.Project;
import com.sp.app.project.ProjectService;

@Controller
@RequestMapping("/pjtmem/")
public class PjtmemController {
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private MempjtService mempjtService;
	
	@Autowired
	private PjtmemService pjtmemService;
	
	@Autowired
	private CodeConverter codeConverter;
	
	@RequestMapping("list")
	public String list(
			@RequestParam long pjtId,
			Model model) throws Exception{
		
		Project project = projectService.readProject(pjtId);
		
		if(project == null) {
			return "redirect:/project/list";
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("pjtId", pjtId);
		
		
		List<Mempjt> list = pjtmemService.listPjtmem(map);
		
		for(Mempjt mempjt : list) {
			String gradeNumber = mempjt.getGrade();
			String gradeKorean = codeConverter.getGradeName(gradeNumber);
			mempjt.setGrade(gradeKorean);
			
			String roleNumber = mempjt.getPjtRole();
			String roleKorean = codeConverter.getRoleName(roleNumber);
			mempjt.setPjtRole(roleKorean);
		}
		
		model.addAttribute("pjtId", pjtId);
		model.addAttribute("project", project);
		model.addAttribute("list", list);

		return "pjtmem/pjtmemList";
	}
	
	@RequestMapping("write")
	public String writeForm(
			@RequestParam(value = "name", required = false) String name,
			@RequestParam Long pjtId,
			Model model) throws Exception{
		
		Map<String, Object> map = new HashMap<String, Object>();
			
		map.put("name", name);
		
		
		List<Member> list = pjtmemService.listMember(map);
		
		for(Member member : list) {
			String rankNumber = member.getRank();
			String rankKorean = codeConverter.getRankName(rankNumber);
			member.setRank(rankKorean);
			
			String gradeNumber = member.getGrade();
			String gradeKoran = codeConverter.getGradeName(gradeNumber);
			member.setGrade(gradeKoran);
		}
		
		model.addAttribute("pjtId", pjtId);
		model.addAttribute("list", list);
		model.addAttribute("mode", "write");
	
		
		return "pjtmem/pjtmemWrite";
	}
	
	@PostMapping("write")
	public String writeSubmit(
			@RequestParam("userId") List<Long> userIds,
			@RequestParam("pjtId") Long pjtId) throws Exception{
		
		try {
			for(Long userId : userIds) {
				Mempjt dto = new Mempjt();
				dto.setUserId(userId);
				dto.setPjtId(pjtId);
				mempjtService.insertMempjt(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String redirectUrl = "redirect:/pjtmem/list?pjtId=" + pjtId;
		
		return redirectUrl;
	}
	
	@RequestMapping(value = "delete")
	public String deletePjtmem(@RequestParam("userId") List<Long> userIds,
			@RequestParam("pjtId") Long pjtId,
			Mempjt dto) throws Exception{
		
		for(Long userId : userIds) {
			dto = new Mempjt();
			dto.setUserId(userId);
			dto.setPjtId(pjtId);
			mempjtService.deleteMempjt(dto);
		}
		
		String redirectUrl = "redirect:/pjtmem/list?pjtId=" + pjtId;
		
		return redirectUrl;
	}
	
	@GetMapping(value = "article")
	public String article(@RequestParam long userId,
			@RequestParam long pjtId,
			Model model) throws Exception{
		
		Mempjt dto2 = new Mempjt();
		dto2.setUserId(userId);
		dto2.setPjtId(pjtId);
		Mempjt dto = pjtmemService.readPjtmem(dto2);
		
		model.addAttribute("dto", dto);
		
		return "pjtmem/pjtmemArticle";
	}
	
	@GetMapping(value = "update")
	public String updateForm(@RequestParam long userId,
			@RequestParam long pjtId,
			Model model) throws Exception{
		
		Mempjt dto2 = new Mempjt();
		dto2.setUserId(userId);
		dto2.setPjtId(pjtId);
		Mempjt dto = pjtmemService.readPjtmem(dto2);
		
		Map<String, Object> roleMap = new HashMap<String, Object>();
		roleMap.put("dcode", "D700");
		
		List<Option> roleOptionList = projectService.listOption(roleMap);
		
	    model.addAttribute("userId", userId);
	    model.addAttribute("pjtId", pjtId);
		model.addAttribute("roleOptionList", roleOptionList);
		model.addAttribute("roleMapping", codeConverter.getRoleName(dto.getPjtRole()));
		model.addAttribute("dto", dto);
		
		return "pjtmem/pjtmemUpdate";
	}
	
	@PostMapping(value = "update")
	public String updateSubmit(Mempjt dto,
			@RequestParam long pjtId,
			@RequestParam long userId
			) throws Exception{
		
		try {
			String roleValue = codeConverter.roleToNumber(dto.getPjtRole());
			dto.setPjtRole(roleValue);
			Mempjt dto2 = new Mempjt();
			dto2.setUserId(userId);
			dto2.setPjtId(pjtId);
			mempjtService.updateMempjt(dto); 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	    String redirectUrl = "redirect:/pjtmem/list?pjtId=" + pjtId;
		
		return redirectUrl;
	}
	

}
