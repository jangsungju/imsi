package com.sp.app.project;

public class Project {
	private long pjtId;
	private String pjtName;
	private String pjtStdt;
	private String pjtEnddt;
	private String clientCo;
	public long getPjtId() {
		return pjtId;
	}
	public void setPjtId(long pjtId) {
		this.pjtId = pjtId;
	}
	public String getPjtName() {
		return pjtName;
	}
	public void setPjtName(String pjtName) {
		this.pjtName = pjtName;
	}
	public String getPjtStdt() {
		return pjtStdt;
	}
	public void setPjtStdt(String pjtStdt) {
		this.pjtStdt = pjtStdt;
	}
	public String getPjtEnddt() {
		return pjtEnddt;
	}
	public void setPjtEnddt(String pjtEnddt) {
		this.pjtEnddt = pjtEnddt;
	}
	public String getClientCo() {
		return clientCo;
	}
	public void setClientCo(String clientCo) {
		this.clientCo = clientCo;
	}
	
	
}
