package com.sp.app.member;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.app.code.Option;
import com.sp.app.code.CodeConverter;
import com.sp.app.common.MyUtil;

@Controller
@RequestMapping("/member/")
public class MemberController {
	
	@Autowired 
	private MemberService memberService;
	
	@Autowired
	private MyUtil myUtil;
	
	@Autowired
	private CodeConverter codeConverter;
	
	
	@RequestMapping("list")
	public String list(HttpSession session,
			@RequestParam(value = "page", defaultValue = "1") int current_page,
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "grade", required = false) String grade,
			@RequestParam(value = "employmentStatus", required = false) String employmentStatus,
			@RequestParam(value = "hireDate", required = false) String hireDate,
			@RequestParam(value = "hireDateTo", required = false) String hireDateTo,
			HttpServletRequest req,
			Model model) throws Exception{
		

		Map<String, Object> rankMap = new HashMap<String, Object>();
		rankMap.put("dcode", "D200");
		
		List<Option> rankOptionList = memberService.listOption(rankMap);
		
		Map<String, Object> gradeMap = new HashMap<String, Object>();
		gradeMap.put("dcode", "D300");

		List<Option> gradeOptionList = memberService.listOption(gradeMap);

		Map<String, Object> depFieldMap = new HashMap<String, Object>();
		depFieldMap.put("dcode", "D400");
		
		List<Option> depFieldOptionList = memberService.listOption(depFieldMap);

		Map<String, Object> statusOfficeMap = new HashMap<String, Object>();
		statusOfficeMap.put("dcode", "D500");
		
		List<Option> statusOfficeOptionList = memberService.listOption(statusOfficeMap);
		
		String cp = req.getContextPath();
		
		int size = 4;
		int total_page = 0;
		int dataCount = 0;
	
		Map<String, Object> map = new HashMap<String, Object>();
		
		    map.put("name", name);
		    
		    String gradeValue = codeConverter.gradeToNumber(grade);
			if (grade != null && !grade.isEmpty()) {
			    map.put("grade", gradeValue);
			}
			
			String staValue = codeConverter.staToNumber(employmentStatus);
			if (employmentStatus != null && !employmentStatus.isEmpty()) {
				map.put("employmentStatus", staValue);
			}

		    if (hireDate != null && !hireDate.isEmpty()) {
		        map.put("hireDate", hireDate);
		    }

		    if (hireDateTo != null && !hireDateTo.isEmpty()) {
		        map.put("hireDateTo", hireDateTo);
		    }
		    
		    dataCount = memberService.dataCount(map);
			if(dataCount != 0) {
				total_page = myUtil.pageCount(dataCount, size);
			}
			
			if(total_page < current_page) {
				current_page = total_page;
			}
			
			int offset = (current_page - 1) * size;
			if(offset < 0) offset = 0;
			
			    map.put("offset", offset);
			    map.put("size", size);
	    

		List<Member> list = memberService.listMember(map);

		for (Member member : list) {
			String rankNumber = member.getRank(); // 데이터베이스로부터 읽어온 직급 숫자
			String rankKorean = codeConverter.getRankName(rankNumber); // 직급 숫자를 한글 값으로 변환
			member.setRank(rankKorean); // 변환된 한글 값을 Member 객체에 저장
			
			String gradeNumber = member.getGrade(); 
			String gradeKorean = codeConverter.getGradeName(gradeNumber);
			member.setGrade(gradeKorean); 
			
			String staNumber = member.getStatusOffice();
			String staKorean = codeConverter.getStaName(staNumber); 
			member.setStatusOffice(staKorean); 
			
			String depNumber = member.getDeptField(); 
			String depKorean = codeConverter.getDepName(depNumber); 
			member.setDeptField(depKorean); 
		}
		
	
		String query = "";
		String listUrl;
		String articleUrl;
		
		articleUrl = cp + "/member/article";
		
		listUrl = cp + "/member/list";
		
		articleUrl = cp + "/member/article?page=" + current_page;
		if(name != null && name.length() != 0 || 
				grade != null && grade.length() != 0 ||
				employmentStatus != null && employmentStatus.length() != 0 ||
				hireDate != null && hireDate.length() != 0 ||
				hireDateTo != null && hireDateTo.length() != 0) {
			query = "&name=" + name + "&grade=" + grade + "&employmentStatus=" + employmentStatus + "&hireDate=" + hireDate + "&hireDateTo" + hireDateTo;
		}
		
		listUrl += "?" + query;
		articleUrl += "&" + query;
		
	    String paging = myUtil.paging(current_page, total_page, listUrl);


		model.addAttribute("rankOptionList", rankOptionList);
		model.addAttribute("gradeOptionList", gradeOptionList);
		model.addAttribute("depFieldOptionList", depFieldOptionList);
		model.addAttribute("statusOfficeOptionList", statusOfficeOptionList);
		model.addAttribute("articleUrl", articleUrl);
		model.addAttribute("list", list);
		
		model.addAttribute("page", current_page);
		model.addAttribute("paging", paging);
		model.addAttribute("total_page", total_page);
		model.addAttribute("dataCount", dataCount);
		model.addAttribute("size", size);
		
	return "memberbbs/list";
}
	
	@GetMapping("write")
	public String writeForm(Model model) throws Exception{
		
		Map<String, Object> rankMap = new HashMap<String, Object>();
		rankMap.put("dcode", "D200");
		
		List<Option> rankOptionList = memberService.listOption(rankMap);
		
		Map<String, Object> gradeMap = new HashMap<String, Object>();
		gradeMap.put("dcode", "D300");

		List<Option> gradeOptionList = memberService.listOption(gradeMap);

		Map<String, Object> depFieldMap = new HashMap<String, Object>();
		depFieldMap.put("dcode", "D400");
		
		List<Option> depFieldOptionList = memberService.listOption(depFieldMap);

		Map<String, Object> statusOfficeMap = new HashMap<String, Object>();
		statusOfficeMap.put("dcode", "D500");
		
		List<Option> statusOfficeOptionList = memberService.listOption(statusOfficeMap);

		
		
		model.addAttribute("rankOptionList", rankOptionList);
		model.addAttribute("gradeOptionList", gradeOptionList);
		model.addAttribute("depFieldOptionList", depFieldOptionList);
		model.addAttribute("statusOfficeOptionList", statusOfficeOptionList);
		model.addAttribute("mode", "write");

		return "memberbbs/write";
	}
	
	@PostMapping("write")
	public String writeSubmit(Member dto, HttpSession session) throws Exception{

		String root = session.getServletContext().getRealPath("/");
		String pathname  = root + "uploads" + File.separator + "member";
		
		try {
			String depValue = codeConverter.depToNumber(dto.getDeptField());
			String gradeValue = codeConverter.gradeToNumber(dto.getGrade());
			String rankValue = codeConverter.rankToNumber(dto.getRank());
			String staValue = codeConverter.staToNumber(dto.getStatusOffice());
			dto.setDeptField(depValue);
			dto.setGrade(gradeValue);
			dto.setRank(rankValue);
			dto.setStatusOffice(staValue);
			memberService.insertMember(dto, pathname);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/member/list";
	}
	

	
	
	@RequestMapping(value = "article", method = RequestMethod.GET)
	public String article(@RequestParam long userId,
			Model model) throws Exception {

		Member dto = memberService.readMember(userId);
		
		if (dto == null) {
			return "redirect:/member/list";
		}
		
		
		String rankNumber = dto.getRank(); // 데이터베이스로부터 읽어온 직급 숫자
		String rankKorean = codeConverter.getRankName(rankNumber); // 직급 숫자를 한글 값으로 변환
		dto.setRank(rankKorean); // 변환된 한글 값을 Member 객체에 저장
		
		String gradeNumber = dto.getGrade(); 
		String gradeKorean = codeConverter.getGradeName(gradeNumber);
		dto.setGrade(gradeKorean); 
		
		String staNumber = dto.getStatusOffice();
		String staKorean = codeConverter.getStaName(staNumber); 
		dto.setStatusOffice(staKorean); 
		
		String depNumber = dto.getDeptField(); 
		String depKorean = codeConverter.getDepName(depNumber); 
		dto.setDeptField(depKorean); 
	    
		
		model.addAttribute("dto", dto);
		
		return "memberbbs/article";
	}
	
	/*
	@RequestMapping(value = "delete")
	public String deleteMember(@RequestParam("userId") List<Long> userIds ,
			HttpSession session) throws Exception{
		
		String root = session.getServletContext().getRealPath("/");
		String pathname = root + "uploads" + File.separator + "member";
		
		for (Long userId : userIds) {
	        memberService.updateMember(userId);
	    }
		
		return "redirect:/member/list";
	}
	
	*/
	
	@RequestMapping(value = "delete")
	public String deleteMember(Member dto,
			@RequestParam("userId") List<Long> userIds) throws Exception{
		
		for(Long userId : userIds) {
			dto.setUserId(userId);
			memberService.deleteMember(dto);
		}
		
		return "redirect:/member/list";
	}
	
	@RequestMapping(value = "update", method = RequestMethod.GET)
	public String updateForm(@RequestParam long userId,
			Model model) throws Exception {

		Member dto = memberService.readMember(userId);
		
		Map<String, Object> rankMap = new HashMap<String, Object>();
		rankMap.put("dcode", "D200");
		
		List<Option> rankOptionList = memberService.listOption(rankMap);
		
		Map<String, Object> gradeMap = new HashMap<String, Object>();
		gradeMap.put("dcode", "D300");

		List<Option> gradeOptionList = memberService.listOption(gradeMap);

		Map<String, Object> depFieldMap = new HashMap<String, Object>();
		depFieldMap.put("dcode", "D400");
		
		List<Option> depFieldOptionList = memberService.listOption(depFieldMap);

		Map<String, Object> statusOfficeMap = new HashMap<String, Object>();
		statusOfficeMap.put("dcode", "D500");
		
		List<Option> statusOfficeOptionList = memberService.listOption(statusOfficeMap);

		
		model.addAttribute("rankOptionList", rankOptionList);
		model.addAttribute("gradeOptionList", gradeOptionList);
		model.addAttribute("depFieldOptionList", depFieldOptionList);
		model.addAttribute("statusOfficeOptionList", statusOfficeOptionList);
	    model.addAttribute("rankMapping", codeConverter.getRankName(dto.getRank()));
	    model.addAttribute("gradeMapping", codeConverter.getGradeName(dto.getGrade()));
	    model.addAttribute("staMapping", codeConverter.getStaName(dto.getStatusOffice()));
	    model.addAttribute("depMapping", codeConverter.getDepName(dto.getDeptField()));

		model.addAttribute("mode", "update");
		model.addAttribute("dto", dto);

		return "memberbbs/write";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String updateSubmit(Member dto,
			HttpSession session) throws Exception {
		try {
			
			String root = session.getServletContext().getRealPath("/");
			String pathname = root + "uploads" + File.separator + "member";
			
			String depValue = codeConverter.depToNumber(dto.getDeptField());
			String gradeValue = codeConverter.gradeToNumber(dto.getGrade());
			String rankValue = codeConverter.rankToNumber(dto.getRank());
			String staValue = codeConverter.staToNumber(dto.getStatusOffice());
			dto.setDeptField(depValue);
			dto.setGrade(gradeValue);
			dto.setRank(rankValue);
			dto.setStatusOffice(staValue);

			if (dto.getSelectFile() == null || dto.getSelectFile().isEmpty()) {
				Member dto2 = memberService.readFile(dto.getUserId());
				dto.setProfileImg(dto2.getProfileImg());
			} 
			
			memberService.updateMember(dto, pathname);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:/member/list";
	}
	

	
}
