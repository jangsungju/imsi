package com.sp.app.project;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.app.code.Option;
import com.sp.app.code.CodeConverter;

@Controller
@RequestMapping("/project/")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private CodeConverter codeConverter;
	
	@RequestMapping("list")
	public String list(HttpServletRequest req,
			@RequestParam(value = "pjtName", required = false) String pjtName,
			@RequestParam(value = "clientCo", required = false) String clientCo,
			@RequestParam(value = "pjtStdt", required = false) String pjtStdt,
			@RequestParam(value = "pjtEnddt", required = false) String pjtEnddt,
			Model model) throws Exception{
		
		String cp = req.getContextPath();
		
		Map<String, Object> clientMap = new HashMap<String, Object>();
		clientMap.put("dcode", "D600");
		
		List<Option> clientOptionList = projectService.listOption(clientMap);
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("pjtName", pjtName);
		
		String coValue = codeConverter.coToNumber(clientCo);
		if (clientCo != null && !clientCo.isEmpty()) {
		    map.put("clientCo", coValue);
		}
		
		if (pjtStdt != null && !pjtStdt.isEmpty()) {
			map.put("pjtStdt", pjtStdt);
		}

		if (pjtEnddt != null && !pjtEnddt.isEmpty()) {
			map.put("pjtEnddt", pjtEnddt);
		}
		
	    
		List<Project> list = projectService.listProject(map);
		
		for(Project project : list) {
			String coNumber = project.getClientCo();
			String coKorean = codeConverter.getCoName(coNumber);
			project.setClientCo(coKorean);
		}
		
		String query = "";
		String articleUrl;
		
		articleUrl = cp + "/project/article";
		
		articleUrl = cp + "/project/article";
		if(pjtName != null && pjtName.length() != 0 ||
				clientCo != null && clientCo.length() != 0 ||
				pjtStdt != null && pjtStdt.length() != 0 ||
				pjtEnddt != null && pjtEnddt.length() != 0) {
			query = "pjtName=" + pjtName + "&clientCo=" + clientCo + "&pjtStdt=" + pjtStdt + "&pjtEnddt=" + pjtEnddt;
		}

		articleUrl += "?" + query;
		
		
		model.addAttribute("articleUrl", articleUrl);
		model.addAttribute("clientOptionList", clientOptionList);
		model.addAttribute("list", list);

		return "project/projectList";
}
	@GetMapping("write")
	public String writeForm(Model model) throws Exception{
		
		Map<String, Object> clientMap = new HashMap<String, Object>();
		clientMap.put("dcode", "D600");
		
		List<Option> clientOptionList = projectService.listOption(clientMap);
		
		model.addAttribute("clientOptionList", clientOptionList);
		model.addAttribute("mode", "write");
		
		return "project/projectWrite";
		
	}
	
	@PostMapping("write")
	public String writeSubmit(Project dto) throws Exception{
		
		try {
			String coValue = codeConverter.coToNumber(dto.getClientCo());
			dto.setClientCo(coValue);
			projectService.insertProject(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/project/list";
	}
	
	@RequestMapping(value = "article", method = RequestMethod.GET)
	public String article(@RequestParam long pjtId,
			Model model) throws Exception{
		
		Project dto = projectService.readProject(pjtId);
		
		if (dto == null) {
			return "redirect:/project/list";
		}
		
	    
		String coNumber = dto.getClientCo();
		String coKorean = codeConverter.getCoName(coNumber);
		dto.setClientCo(coKorean);
		
		model.addAttribute("dto", dto);
		
		return "project/projectArticle";
	}
	
	/*
	@RequestMapping(value = "delete")
	public String deleteProject(@RequestParam("pjtId") List<Long> pjtIds) throws Exception{
		
		for (Long pjtId : pjtIds) {
	        projectService.deleteProject(pjtId);
	    }
		
		return "redirect:/project/list";
	}
	*/
	
	@RequestMapping(value = "delete")
	public String delteProject(Project dto,
			@RequestParam("pjtId") List<Long> pjtIds) throws Exception{

		for(Long pjtId : pjtIds) {
			dto.setPjtId(pjtId);
			projectService.deleteProject(dto);
		}
		
		return "redirect:/project/list";
	}
	
	@RequestMapping(value = "update", method = RequestMethod.GET)
	public String updateForm(@RequestParam long pjtId,
			Model model) throws Exception{
		
		Project dto = projectService.readProject(pjtId);
		
		Map<String, Object> clientMap = new HashMap<String, Object>();
		clientMap.put("dcode", "D600");
		
		List<Option> clientOptionList = projectService.listOption(clientMap);

		
	    model.addAttribute("coMapping", codeConverter.getCoName(dto.getClientCo()));
		model.addAttribute("clientOptionList", clientOptionList);
		model.addAttribute("mode", "update");
		model.addAttribute("dto", dto);

		return "project/projectWrite";
	}
	
	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String updateSubmit(Project dto,
			HttpSession session) throws Exception {
		try {
			String coValue = codeConverter.coToNumber(dto.getClientCo());
			dto.setClientCo(coValue);
			projectService.updateProject(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:/project/list";
	}
	

	
}
