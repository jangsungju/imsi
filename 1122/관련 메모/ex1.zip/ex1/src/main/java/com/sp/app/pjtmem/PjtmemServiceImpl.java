package com.sp.app.pjtmem;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.app.common.CommonDAO;
import com.sp.app.member.Member;
import com.sp.app.mempjt.Mempjt;

@Service("pjtmem.pjtmemService")
public class PjtmemServiceImpl implements PjtmemService {
	
	@Autowired
	CommonDAO dao;

	@Override
	public List<Member> listMember(Map<String, Object> map) {
		List<Member> list = null;
		
		try {
			list = dao.selectList("pjtmem.listMember", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Mempjt> listPjtmem(Map<String, Object> map) {
		List<Mempjt> list = null;
		
		try {
			list = dao.selectList("pjtmem.listPjtmem", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Mempjt readPjtmem(Mempjt dto) throws Exception {
		try {
			dto = dao.selectOne("pjtmem.readPjtmem", dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

}
