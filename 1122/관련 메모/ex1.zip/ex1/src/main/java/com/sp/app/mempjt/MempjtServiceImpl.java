package com.sp.app.mempjt;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.app.common.CommonDAO;

@Service("mempjt.mempjtService")
public class MempjtServiceImpl implements MempjtService{
	@Autowired
	CommonDAO dao;
	
	@Override
	public void insertMempjt(Mempjt dto) throws Exception {
		try {
			dao.insertData("mempjt.insertMempjt", dto);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<Mempjt> listMempjt(Map<String, Object> map) {
		List<Mempjt> list = null;
		
		try {
			list = dao.selectList("mempjt.listMempjt", map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public void deleteMempjt(Mempjt dto) throws Exception {
		try {
			dao.deleteData("mempjt.deleteMempjt", dto);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Mempjt readMempjt(Mempjt dto) throws Exception {
		
		try {
			dto = dao.selectOne("mempjt.readMempjt", dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}

	@Override
	public void updateMempjt(Mempjt dto) throws Exception {
		try {
			dao.updateData("mempjt.updateMempjt", dto);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
